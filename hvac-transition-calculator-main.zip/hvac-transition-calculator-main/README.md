# Azure Billing & Cost Management

## Project

HVAC Duct Transition Design and Calculation Web Application

## My Role

Billing and Cost Management

I was responsible for monitoring and managing the Azure costs associated
with the project.

## What I Implemented

- Created a monthly Azure budget
- Configured budget thresholds
- Configured cost alerts
- Monitored Azure spending using Cost Analysis
- Checked resource-level costs
- Monitored Azure App Service-related costs
- Reviewed billing information

## Azure Services / Features Used

- Azure Cost Management
- Cost Analysis
- Azure Budgets
- Cost Alerts
- Azure Billing
- Azure App Service

## Objective

The objective of my work was to monitor Azure expenditure and help prevent
unexpected cloud costs by using budgets, alerts, and Cost Management features.

## Evidence

Screenshots of the Azure Portal configuration are available in the
`screenshots` folder.

Detailed documentation is available in the `documentation` folder.